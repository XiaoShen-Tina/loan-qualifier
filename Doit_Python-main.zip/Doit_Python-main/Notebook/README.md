# 주피터 노트북  파일

파일           | 내용
:------------- |:-------------
[03.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/03.ipynb) | 03 데이터 분석에 필요한 연장 챙기기
[04.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/04.ipynb) | 04 데이터 프레임의 세계로!
[05.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/05.ipynb) | 05 데이터 분석 기초! - 데이터 파악하기, 다루기 쉽게 수정하기
[06.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/06.ipynb) | 06 자유자재로 데이터 가공하기
[07.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/07.ipynb) | 07 데이터 정제 - 빠진 데이터, 이상한 데이터 제거하기
[08.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/08.ipynb) | 08 그래프 만들기
[09.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/09.ipynb) | 09 데이터 분석 프로젝트 - 한국인의 삶을 파악하라!
[10.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/10.ipynb) | 10 텍스트 마이닝
[11.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/11.ipynb) | 11 지도 시각화
[12.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/12.ipynb) | 12 인터랙티브 그래프
[13.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/13.ipynb) | 13 마크다운으로 데이터 분석 보고서 만들기
[14.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/14.ipynb) | 14 통계 분석 기법을 이용한 가설 검정
[15.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/15.ipynb) | 15 머신러닝을 이용한 예측 분석
[16.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/16.ipynb) | 16 데이터를 추출하는 다양한 방법
[17.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/17.ipynb) | 17 자료 구조 다루기
[Quiz.ipynb](https://github.com/youngwoos/Doit_Python/blob/main/Notebook/Quiz.ipynb) | 퀴즈 정답

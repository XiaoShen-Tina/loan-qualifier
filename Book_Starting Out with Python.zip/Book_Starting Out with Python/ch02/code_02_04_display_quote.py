# code_02_04_display_quote.py
print('Your assignement is to read "Hamlet" by tomorrow.')
print("""I'm reading "Hamlet" tonight.""")
print("""One Two Three""")
# code_02_01_output.py

print('Kate Austen')
print('123 Full Circle Drive') 
print('Asheville, NC 28899')
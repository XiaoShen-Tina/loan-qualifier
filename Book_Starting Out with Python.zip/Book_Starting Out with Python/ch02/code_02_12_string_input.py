# code_02_12_string_input.py
# Input
first_name = input('Enter your first name: ') # Get the user's first name.
last_name = input('Enter your last name: ') # Get the user's last name.

# Display
print('Hello', first_name, last_name) # Print a greeting to the user.
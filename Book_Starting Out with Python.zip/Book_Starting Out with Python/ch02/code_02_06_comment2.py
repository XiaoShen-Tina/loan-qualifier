# code_02_06_comment2.py
print('Kate Austen') # Display the name.
print('123 Full Circle Drive') # Display the address.
print('Asheville, NC 28899') # Display the city, state, and ZIP.



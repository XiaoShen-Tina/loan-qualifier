# code_02_09_variable_demo3.py
# This program demonstrates a variable.
room = 503
print('I am staying in room number', room)
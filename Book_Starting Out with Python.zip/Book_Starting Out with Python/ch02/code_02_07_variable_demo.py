# code_02_07_variable_demo.py
# This program demonstrates a variable. 
room = 503
print('I am staying in room number')
print(room)
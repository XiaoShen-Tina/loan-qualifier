# code_02_03_apostrophe.py
print("Don't fear!")
print("I'm here!")
# code_02_25_inputbox.py
import turtle
num = turtle.numinput('Input', 'Enter a number', default=10, minval=0, maxval=100)
txt = turtle.textinput('Input', 'Enter your name')
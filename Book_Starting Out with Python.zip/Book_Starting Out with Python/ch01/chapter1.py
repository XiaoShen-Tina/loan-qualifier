# Chapter 1 - Introduction to Computers and Programming
print('Python programming is fun!')
print('파이톤 프로그래밍은 즐겁다!')
print('Python 编程很有趣！')

# code_03_00_decision_structure_01.py
sales = float(input('What is your sales total?'))

if sales > 50000:
    bonus = 500
    commission_rate = 0.12
    print('you met your sales quota!')
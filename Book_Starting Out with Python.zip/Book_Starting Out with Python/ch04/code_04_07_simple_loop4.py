# code_04_07_simple_loop4.py
# This program demonstrates how the range
# function can be used with a for loop.

# Print a message five times.
for x in range(6):
    print('Hello world')

for num in range(1, 6): 
    print(num)

for num in range(1, 10, 2): 
    print(num)
# code_05_13_global1.py
#5.6: Global Variables and Global Constants

# Create a global variable
my_value = 10

# The show_value function prints the value of the global variable
def show_value():
    print(my_value)

# Call the show_value function
show_value()

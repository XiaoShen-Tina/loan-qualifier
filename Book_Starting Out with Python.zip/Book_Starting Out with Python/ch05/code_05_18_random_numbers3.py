# code_05_18_random_numbers3.py
#5.7: Introduction to Value-Returning Functions: Generating Random Numbers

import random

def main():
    for count in range(5):
        print(random.randint(1,100))

main()
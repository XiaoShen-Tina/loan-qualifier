# code_05_01_function_demo.py
# 5.2: Defining and Calling a Void Function

# This program demonstrates a function.

# First, we define a function named message. 
def message():
    print('This is Chad,') 
    print('An assistant professor of WKU.')

# Call the message function. 
message()
# code_05_00_myfunction.py
# 5.1: Introduction to Function

# This program demonstrates a function.

# First, we define a function named message. 
def mysum(num1, num2):
    mysum = num1 + num2
    print(mysum)

def myaver(num1, num2):
    myaver = (num1 + num2) / 2
    print(myaver)

# Call the message function. 
mysum(24, 25)
myaver(87, 88)






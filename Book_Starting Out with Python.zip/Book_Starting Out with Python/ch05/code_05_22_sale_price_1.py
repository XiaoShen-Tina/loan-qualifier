# code_05_22_sale_price_1.py
#5.8: Writing Your Own Value-Returning Functions

# This program calculates a retail item's sale price.


# DISCOUNT_PERCENTAGE is used as a global constant for the discount percentage. 
DISCOUNT_PERCENTAGE = 0.20

# The main function. 
def main():
    # Get the item's regular price. Get regular price from user
    regular_price = 0
    # Calculate the sale price.
    sale_price = 0
    # Display the sale price.

# The get_regular_price function 

# discount function

# Call the main function.
main()
# code_05_22_sale_price_0_empty.py
#5.8: Writing Your Own Value-Returning Functions

# This program calculates a retail item's sale price.


# DISCOUNT_PERCENTAGE is used as a global constant for the discount percentage. 

# The main function. 
    # Get the item's regular price. Get regular price from user
    # Calculate the sale price.
    # Display the sale price.

# The get_regular_price function 

# discount function

# Call the main function.

import code_11_09_animals
mammal = code_11_09_animals.Mammal('regular mammal')
mammal.show_species()
mammal.make_sound()
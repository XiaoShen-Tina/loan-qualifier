import code_11_09_animals
cat = code_11_09_animals.Cat()
cat.show_species()
cat.make_sound()
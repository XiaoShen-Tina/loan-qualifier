import code_11_09_animals
dog = code_11_09_animals.Dog()
dog.show_species()
dog.make_sound()
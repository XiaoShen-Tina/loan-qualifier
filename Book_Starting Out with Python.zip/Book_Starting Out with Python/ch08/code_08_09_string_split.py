# code_08_09_string_split.py
# This program demonstrates the split method

def main():
    # Create a string with multiple words
    my_string = 'One two three four'

    # Split the string
    word_list = my_string.split()

    # Print the list of words
    print(word_list)

main()
# Get three test scores and calculate the total and average with proper message
score1 = 1
score2 = 2
score3 = 3
# Calculate the amount of 3 scores
total_scores = score1 + score2 + score3
# Calculate the average number of 3 scores
average_scores = (score1 + score2 + score3) / 3
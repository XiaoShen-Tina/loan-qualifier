# You have to write a program that determine whether you will accept loan application or reject. You will determine acceptence based on annual salary and year of work. Acceptance standard is annual salary > 500,000 yuan and > 5 years of work in current work.
annual_salary = int(input("Enter your annual salary: "))
year_work = int(input("Enter your year of work: "))
if annual_salary >= 500000: 
    if year_work >= 5:
       print("Your application is accepted")
    else:
        print("Sorry your application is rejected")
else:
    print("Sorry your application is rejected")